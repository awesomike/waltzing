use std::env;
use std::path::PathBuf;
use std::process::Command;

fn compile_waltzing_templates() -> Result<(), Box<dyn std::error::Error>> {
    #[cfg(windows)]
    const PATH_SEPARATOR: char = ';';
    #[cfg(not(windows))]
    const PATH_SEPARATOR: char = ':';

    #[cfg(windows)]
    const WALTZING_EXE: &str = "waltzing.exe";
    #[cfg(not(windows))]
    const WALTZING_EXE: &str = "waltzing";

    let path_var = env::var("PATH").expect("PATH environment variable not set");
    let waltzing_path = path_var
        .split(PATH_SEPARATOR)
        .map(PathBuf::from)
        .find(|path| path.join(WALTZING_EXE).exists())
        .map(|path| path.join(WALTZING_EXE));

    let waltzing_path = waltzing_path.unwrap_or_else(|| {
        let home_dir = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .expect("Could not determine home directory");
        PathBuf::from(home_dir).join(".local").join("bin").join(WALTZING_EXE)
    });

    if !waltzing_path.exists() {
        panic!("waltzing not found in PATH or at {}", waltzing_path.display());
    }

    let out_dir = format!("{}/templates", std::env::var("OUT_DIR")?);
    let templates_dir = PathBuf::from("templates");

    let status = Command::new(&waltzing_path)
        .args(["-i", &templates_dir.display().to_string(), "-o", &out_dir])
        .status()
        .expect("Failed to run waltzing compiler");

    if !status.success() {
        panic!("Waltzing compilation failed");
    }

    println!("cargo:rerun-if-changed={}", templates_dir.display());
    Ok(())
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    compile_waltzing_templates()?;
    println!("cargo:rerun-if-changed=build.rs");
    Ok(())
}
