pub mod templates {
    include!(concat!(env!("OUT_DIR"), "/templates/mod.rs"));
}

fn main() {
    // Render the home page template
    let html = templates::pages::home::apply("Waltzing".to_string());
    println!("{}", html);
}
