# Waltzing Starter Project

A minimal starter project for [Waltzing](https://waltzing.awesomike.com), the compile-time template engine for Rust.

## Prerequisites

Install the Waltzing CLI:

```bash
curl -fsSL https://waltzing.awesomike.com/install | bash
```

## Getting Started

1. Build and run:
   ```bash
   cargo run
   ```

2. Edit templates in `templates/` directory

3. Templates are automatically recompiled when you run `cargo build`

## Project Structure

```
.
├── build.rs              # Compiles templates at build time
├── src/
│   └── main.rs           # Your application code
└── templates/
    ├── layouts/
    │   └── base.wtz      # Base HTML layout
    └── pages/
        └── home.wtz      # Home page template
```

## Learn More

- [Documentation](https://waltzing.awesomike.com/docs)
- [Template Syntax](https://waltzing.awesomike.com/docs/syntax)
